---
  title: "Slug Test Analysis"
author: "Devin Hunt, Mitchell Zombek"
date: "5/10/2022"
output: 
  html_document:
  toc: TRUE
theme: cerulean
---
  
  ```{r setup, include=FALSE}

install.packages('tidyverse')
install.packages('plotly')
install.packages('here')

library(tidyverse)
library(plotly)
library(here)
knitr::opts_chunk$set(echo = TRUE, message = FALSE, warning = FALSE)
```
# Overview

## Objectives:
In this lesson, you will learn:
  - Procedure for slug testing in a well
- Using Theis graphs to estimate hydraulic conductivity (k) of an underground aquifer

## Collecting Slug Test Data
In this short video, Devin and Mitchell explain the purpose of slug testing and demonstrate the collection process at Colorado State University's "Get Wet" site.

<div align="center">
<iframe width="560" height="315" frameborder="0" src="https://www.youtube.com/embed/q0ySiR3pI9w?" data-external="1"></iframe>
</div>

Remember to collect metadata when collecting data out in the field. More information is better than none!

## Interpreting the data

Our demonstration was bogus because the Piezometer was not recording data. To make this lesson more easily reproducable, we have found [professionally collected data](https://www.sciencebase.gov/catalog/item/5e4c6dd4e4b0ff554f6c67c4) from the USGS.

[Here is what their well and operation looks like](https://www.sciencebase.gov/catalog/file/get/5e4c6dd4e4b0ff554f6c67c4?f=__disk__cc%2Fdb%2F37%2Fccdb37199f153442f23851f09cb7227b19bde21d&allowOpen=true)

This slug test data was collected in Hinkley and Water Valleys, California. Their data is available in a table under "Attached Files". Of the large dataset, we will be working with site BG-0004A taken on March 9th, 2016.

## Download the Data
```{r Downloading Data}
# Read in the CSV
BG_0004A <- read_csv(here('BG-0004A-traditional_2016-03-09.csv'))

# Preview your data
head(BG_0004A)
```

## Plotting the data

```{r Plotting Data}

ggplot(BG_0004A, aes(Seconds, `Pressure-poundspersquareinch`)) + 
  geom_point()

```

As we can see, some data could be filtered to improve this graph. We can either modify the ylim() of the ggplot, or filter for any y value less than 4.
Additionally, we can view specific curves by converting the ggplot into a plotly

```{r}
p1 <- ggplotly(BG_0004A %>% 
         ggplot(., aes(x = Seconds, y = `Pressure-poundspersquareinch`)) + 
         geom_point() + 
         geom_line() + 
         ylim(4, 6.1) + 
         geom_abline(slope = 0, intercept = 5.1, color = "deeppink2"))

ggplotly(p1)

```


The upward spike in pressure indicated a rise in water level, this is the point in which the slug is dropped into the water. The data collector waits until the water level stabilizes, then pulling out the slug has an opposite effect.


Here is that same graph with the pressure data converted to depth to water. (Notice that the spikes are inverted - higher pressure equals a shorter distance to water in the well)
```{r}

p2 <- ggplotly(BG_0004A %>% 
         ggplot(., aes(x = Seconds, y = `Depthtowater-feet`)) + 
         geom_point() + 
         geom_line() + 
         ylim(47, 51) + 
         geom_abline(slope = 0, intercept = 49.13, color = "deeppink2"))

ggplotly(p2)
```

## Understanding the data

With the graphed data, we can then use the [Theis Method](http://www.aqtesolv.com/theis-recovery.htm#:~:text=The%20Theis%20(1935)%20solution%20is,termination%20of%20a%20pumping%20test.) to then calculate drawdown, and **hydraulic conductivity**.

The next step in this process would be to look at one upward, and one downward spike. We can look at all the displacements or recoveries, then work with the provided graph alignments to determine our values.

![Displacement (Placing Slug into water)](/cloud/project/BG-0004A_curve_traditional_displacement.jpg)    
![Recovery (rapidly removing slug from water)](/cloud/project/BG-0004A_curve_traditional_recovery.jpg)

Using the Theis equations from above, they can determine the hydraulic conductivity (K) for the groundwater level.



